function [Aircraft] = PowerAvailable(Aircraft)
%
% [Aircraft] = PowerAvailable(Aircraft)
% written by Paul Mokotoff, prmoko@umich.edu
% last updated: 16 feb 2026
%
% For a given propulsion architecture, compute the power available.
%
% INPUTS:
%     Aircraft - structure with information about the aircraft's propulsion
%                system architecture and SLS thrust/power requirements.
%                size/type/units: 1-by-1 / struct / []
%
% OUTPUTS:
%     Aircraft - updated structure with the total thrust power (TV)
%                that can be provided by the propulsion system.
%                size/type/units: 1-by-1 / struct / []
%


%% PRE-PROCESSING %%
%%%%%%%%%%%%%%%%%%%%

% get the segment id
SegsID = Aircraft.Mission.Profile.SegsID;

% get the beginning and ending control point indices
SegBeg = Aircraft.Mission.Profile.SegBeg(SegsID);
SegEnd = Aircraft.Mission.Profile.SegEnd(SegsID);

% aircraft performance history
TAS = Aircraft.Mission.History.SI.Performance.TAS(SegBeg:SegEnd);
Rho = Aircraft.Mission.History.SI.Performance.Rho(SegBeg:SegEnd);

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% get information about the  %
% configuration and mission  %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% aircraft class
aclass = Aircraft.Specs.TLAR.Class;

% get the transmitter types
TrnType = Aircraft.Specs.Propulsion.PropArch.TrnType;

% get the number of control points in the segment
npnt = length(TAS);

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% get information about the  %
% power sources in the arch. %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get the propulsion architecture matrix
Arch = Aircraft.Specs.Propulsion.PropArch.Arch;

% get the efficiency matrices
EtaUps = Aircraft.Specs.Propulsion.PropArch.EtaUps;

% get the operational matrices
OperUps = Aircraft.Specs.Propulsion.PropArch.OperUps;

% get the upstream power splits
LamUps = Aircraft.Mission.History.SI.Power.LamUps(SegBeg:SegEnd, :);

% check for windmilling
Windmill = Aircraft.Mission.History.SI.Power.Windmill(SegBeg:SegEnd, :);

% get the number of components
ncomp = length(Arch);

% get the number of sources and transmitters
nsrc = length(Aircraft.Specs.Propulsion.PropArch.SrcType);
ntrn = length(Aircraft.Specs.Propulsion.PropArch.TrnType);

% get the number of sinks
nsnk = ncomp - nsrc - ntrn;

% get the sink indices
isnk = (nsrc + ntrn + 1) : ncomp;


%% COMPUTE THE POWER AVAILABLE FOR THE TRANSMITTERS %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% remember the SLS thrust/power available in each transmitter
ThrustAv = repmat(Aircraft.Specs.Propulsion.SLSThrust, npnt, 1);
 PowerAv = repmat(Aircraft.Specs.Propulsion.SLSPower , npnt, 1);
 
% remember the SLS power separately
SLSPower = Aircraft.Specs.Propulsion.SLSPower;

% get indices for transmitters
itrn = (1:ntrn) + nsrc;

% find all upstream transmitters (i.e., input at least one transmitter and
% maybe a source)
UpTrn = find(sum(Arch(itrn, itrn), 1) > 0);
 
% assume no power available at the propellers yet (need to propagate)
PowerAv(:, UpTrn) = 0; %#ok<FNDSB>
 
% loop through all transmitters
for jtrn = 1:ntrn
    
    % check for the proper power source
    if     (TrnType(jtrn) == 1) % engine
        
        % get the thrust/power available based on the aircraft class
        if      (strcmpi(aclass, "Turbofan" ) == 1)
                
            % lapse the SLS thrust
            ThrustAv(:, jtrn) = PropulsionPkg.EngineLapse(ThrustAv(:, jtrn), aclass, Rho);
            
            % get the available power from the gas-turbine engines
            PowerAv(:, jtrn) = ThrustAv(:, jtrn) .* TAS;
            
        elseif ((strcmpi(aclass, "Turboprop") == 1) || ...
                (strcmpi(aclass, "Piston"   ) == 1) )
            
            % lapse the SLS power
            PowerAv(:, jtrn) = PropulsionPkg.EngineLapse(PowerAv(:, jtrn), aclass, Rho);
                
        else
            
            % throw error
            error("ERROR - PowerAvailable: invalid aircraft class.");
            
        end
        
    elseif (TrnType(jtrn) == 0) % electric motor
        
        % once available, input an electric motor model here

    elseif (TrnType(jtrn) == 2) % fuel cell
        
        % once available, input a fuel cell model here
        
    elseif (TrnType(jtrn) == 3) % electric generator
        
        % once available, input an electric generator model here
        
    elseif (TrnType(jtrn) == 4) % cables
        
        % once available, input a cable model here
        
    elseif (TrnType(jtrn) == 5) % quasi-sinks
        
        % once available, input a quasi-sink model here
        
    else
        
        % throw an error
        error("ERROR - PowerAvailable: invalid power source type in position %d.", jtrn);
        
    end
end

% Apply installed transmitter limits before propagating power downstream.
% Previously, lapse-based engine power could be propagated to the fans and
% sink first and capped only afterward. That left TV based on stale,
% over-limit turbine power even though the stored turbine Pav was capped.
PowerAv = min(PowerAv, repmat(SLSPower, npnt, 1));


%% COMPUTE THE TOTAL POWER AVAILABLE %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% allocate memory for the power available
Pav = zeros(npnt, ncomp);

% get the transmitter and sink indices
idx = (nsrc + 1) : ncomp;

% loop through points to get the power available
for ipnt = 1:npnt
    
    % evaluate the function handles for the current splits
    Lambda = PropulsionPkg.EvalSplit(OperUps, LamUps(ipnt, :));

    % find all upstream transmitters and propellers
    UpTrn = find(sum(Lambda(itrn, itrn), 1) > 0 | (TrnType == 2));
    
    % assume no power available at the propellers yet (need to propagate)
    PowerAv(ipnt, UpTrn) = 0; %#ok<FNDSB>
    
    % get the initial power available
    Pav(ipnt, :) = [zeros(1, nsrc), PowerAv(ipnt, :), zeros(1, nsnk)];
    
    % check if any engines are windmilling
    if (any(Windmill(ipnt, :)))
        
        % get the indices
        OffTrn = Windmill(ipnt, :) + nsrc;
        
        % "turn off" the respective components (set power available to 0)
        Pav(ipnt, OffTrn) = 0;
        
    end
    
    % propagate the power upstream
    Pav(ipnt, idx) = PropulsionPkg.PowerFlow(Pav(ipnt, idx)', Arch(idx, idx), Lambda(idx, idx), EtaUps(idx, idx), +1)';
    
    % Safety check for downstream/derived transmitters whose power is
    % established during propagation. Independent transmitter limits were
    % already applied above, before TV was calculated.
    Overload = Pav(ipnt, itrn) > SLSPower;
    
    % suppress component overloads
    if (any(Overload))
        
        % get the indices
        TempIdx = find(Overload);
        
        % update the power available
        Pav(ipnt, TempIdx + nsrc) = SLSPower(TempIdx);
        
        % get the sink inputs
        [TempTrn, ~] = find(Arch(:, isnk));
        
        % get a temporary index
        TempIdx = [TempTrn', isnk];
        
        % re-compute the power at the sink(s)
        Pav(ipnt, TempIdx) = PropulsionPkg.PowerFlow(Pav(ipnt, TempIdx)', Arch(TempIdx, TempIdx), Lambda(TempIdx, TempIdx), EtaUps(TempIdx, TempIdx), +1)';
        
    end
end

% OperUps already applies LamUps while propagating total power to the sink.
% Keep that sink result, but make the stored electric-motor component
% availability consistent with the same upstream split. RecomputeSplits
% reads these component columns to derive LamDwn.
iEM = find(TrnType == 0);
if ~isempty(iEM)
    Pav(:, nsrc + iEM) = Pav(:, nsrc + iEM) .* LamUps(:, iEM);
end

% In fixed-schedule optimization mode, LamUps describes installed
% availability while LamDwn prescribes the actual component ratio. The
% usable sink power must therefore be limited by the first component that
% reaches its available power at that commanded ratio. Summing every active
% component's full Pav would change the climb trajectory before the
% optimizer changes LamDwn and would not reproduce a feasible -1 seed.
if Aircraft.Settings.Analysis.Type == -2 && nsnk == 1
    OperDwn = Aircraft.Specs.Propulsion.PropArch.OperDwn;
    EtaDwn = Aircraft.Specs.Propulsion.PropArch.EtaDwn;
    LamDwn = Aircraft.Mission.History.SI.Power.LamDwn(SegBeg:SegEnd, :);
    TrnSnkIdx = (nsrc + 1):ncomp;

    for ipnt = 1:npnt
        SplitDwn = PropulsionPkg.EvalSplit(OperDwn, LamDwn(ipnt, :));
        UnitReq = zeros(length(TrnSnkIdx), 1);
        UnitReq(end) = 1;
        UnitReq = PropulsionPkg.PowerFlow(UnitReq, ...
            Arch(TrnSnkIdx, TrnSnkIdx)', ...
            SplitDwn(TrnSnkIdx, TrnSnkIdx), ...
            EtaDwn(TrnSnkIdx, TrnSnkIdx), -1);

        TrnReqPerSink = UnitReq(1:ntrn);
        Active = TrnReqPerSink > 1.0e-12;
        if any(Active)
            FixedSplitTV = min(Pav(ipnt, nsrc + find(Active)) ./ ...
                TrnReqPerSink(Active)');
            Pav(ipnt, isnk) = min(Pav(ipnt, isnk), FixedSplitTV);
        end
    end
end

% convert the power available to thrust available
Tav = Pav ./ TAS;

% consolidate power from all sinks for now (later on, a flag will be
% introduced to neglect power off-takes)
TV = sum(Pav(:, nsrc+ntrn+1:end), 2);


%% STORE OUTPUTS IN THE AIRCRAFT STRUCTURE %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% remember the thrust and power available for the transmitters
Aircraft.Mission.History.SI.Power.Pav(SegBeg:SegEnd, :) = Pav;
Aircraft.Mission.History.SI.Power.Tav(SegBeg:SegEnd, :) = Tav;

% remember the power available
Aircraft.Mission.History.SI.Power.TV(SegBeg:SegEnd) = TV;

% ----------------------------------------------------------

end
