function [Aircraft] = EAPAnalysis(Aircraft, Type, MaxIter)
%
% [Aircraft] = EAPAnalysis(Aircraft, Type, MaxIter)
% written by Paul Mokotoff, prmoko@umich.edu
% last updated: 09 jan 2026
%
% For a given aircraft, either:
%
%     (1) perform sizing (an on-design analysis) by iterating over its
%     MTOW, block fuel, battery weight, electric generator weight, and
%     electric motor weight.
%
%     (2) assess its performance (an off-design analysis) by flying a
%     specified mission consisting of takeoff, climb, and cruise segments.
%
% INPUTS:
%     Aircraft - aircraft structure for aircraft to be analyzed.
%                size/type/units: 1-by-1 / struct / []
%
%     Type     - analysis type, which can be either:
%                    a) +1, on -design analysis (sizing + performance).
%                    b) -1, off-design analysis (         performance).
%                size/type/units: 1-by-1 / int / []
%
%     MaxIter  - maximum iterations during sizing.
%                size/type/units: 1-by-1 / int / []
%
% OUTPUTS:
%     Aircraft - updated aircraft structure.
%                size/type/units: 1-by-1 / struct / []
%


%% PRE-PROCESSING AND SETUP %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% check inputs               %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% assume on-design analysis
if (nargin < 2)
    Type = +1;
end

% assume 50 iterations
if (nargin < 3)
    MaxIter = 50;
end

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% get info from the aircraft %
% structure                  %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check for fuel and batteries
Fuel = Aircraft.Specs.Propulsion.PropArch.SrcType == 1;
Batt = Aircraft.Specs.Propulsion.PropArch.SrcType == 0;

% initial weights
MTOW  = Aircraft.Specs.Weight.MTOW;
Wfuel = Aircraft.Specs.Weight.Fuel;
Wbatt = Aircraft.Specs.Weight.Batt;

% get the wing loading
W_S = Aircraft.Specs.Aero.W_S.SLS;

% check for battery cells in series/parallel
SerCells = Aircraft.Specs.Power.Battery.SerCells;
ParCells = Aircraft.Specs.Power.Battery.ParCells;

% if there are cells in series/parallel, use a detailed battery model
if ((~isnan(SerCells)) && (~isnan(ParCells)))
    
    % flag the detailed battery model
    Aircraft.Settings.DetailedBatt = 1;
    
else
    
    % no detailed battery model needed
    Aircraft.Settings.DetailedBatt = 0;
    
end

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% weights setup              %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% throw an error if maximum takeoff weight isn't a number
if (isnan(MTOW))
    error("ERROR - EAPAnalysis: MTOW is NaN."); 
end

% if fuel weight is not a number, assume none is carried
if (isnan(Wfuel))
    Wfuel = zeros(1, max(1, sum(Fuel)));
end

% if battery weight is not a number, assume none is carried
if (isnan(Wbatt))
    Wbatt = zeros(1, max(1, sum(Batt)));
end

% throw an error if wing loading isn't a number
if (isnan(W_S))
    error("ERROR - EAPAnalysis: Wing loading is NaN");
end

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% geometry/visualization     %
% setup                      %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Size wing area only during on-design analysis.  An off-design mission
% changes carried fuel and takeoff weight, not the installed wing geometry.
% Recomputing S = MTOW/W_S for Type < 0 silently shrank the aircraft wing
% on shorter routes and made independently optimized missions inconsistent
% with fixed-aircraft sequence optimization.
if Type > 0 || ~isfield(Aircraft.Specs.Aero, "S") || ...
        ~isscalar(Aircraft.Specs.Aero.S) || ~isfinite(Aircraft.Specs.Aero.S)
    S = MTOW / W_S;
    Aircraft.Specs.Aero.S = S;
else
    S = Aircraft.Specs.Aero.S;
end

% check if the aircraft should be visualized
if (Aircraft.Settings.VisualizeAircraft == 1) && (Aircraft.Settings.Analysis.Type ~= -2)

    % store a nominal wing area (used for scaling geometry up/down)
    Snominal = S;

    % use value prescribed in aircraft specification
    LengthNominal = UnitConversionPkg.ConvLength(Aircraft.Geometry.LengthSet,'m','ft');

    % call geometry with reference num being 1 for nominal
    Aircraft = VisualizationPkg.GeometryDriver(Aircraft, 1, 1, LengthNominal);

end

% ----------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% iteration setup            %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% assume the sizing converges
Aircraft.Settings.Converged = 1;

% define convergence tolerance
EPS = 1.0e-3;

% Number of recent battery-sizing iterations retained for detecting a
% repeated discrete-cell limit cycle. Increase this value to detect longer
% cycles; a cycle must repeat at least twice within this window.
BattCycleHistoryLength = 10;

% Battery limit-cycle detection is only applicable to on-design sizing with
% the detailed (integer series/parallel cell) battery model.
DetectBattCycle = (Type > 0) && (Aircraft.Settings.DetailedBatt == 1) && any(Batt);
BattSizeFixed   = false;
BattHistoryCount = 0;
BattSizeHistory = nan(BattCycleHistoryLength, numel(Wbatt));
BattCellHistory = nan(BattCycleHistoryLength, numel(ParCells));

% Expose the cycle-detection settings and result for post-processing.
Aircraft.Settings.BattCycleHistoryLength = BattCycleHistoryLength;
Aircraft.Settings.BattCycleDetected      = 0;
Aircraft.Settings.BattCyclePeriod        = 0;
Aircraft.Settings.BattSizeFixed          = 0;

% iteration counter
iter = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                            %
% SIZE THE AIRCRAFT          %
%                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize new MTOW if off-design
if Type < 0
    Aircraft.Specs.Weight.MTOW = ...
        Aircraft.Specs.Weight.OEW   +...
        Aircraft.Specs.Weight.Crew   +...
        Aircraft.Specs.Weight.Payload   +...
        Aircraft.Specs.Weight.Fuel   +...
        Aircraft.Specs.Weight.Batt;
end

% initialize the mission history
Aircraft = DataStructPkg.InitMissionHistory(Aircraft);

% PowerOpt stores split schedules in mission-history arrays, so fill them
% after InitMissionHistory creates those arrays.
Aircraft = PropulsionPkg.LamFill(Aircraft);

% print initial size
fprintf(1, "Initial Size:          \n"                                                    );
fprintf(1, "    MTOW  = %.6e lbm   \n",     UnitConversionPkg.ConvMass(MTOW , "kg", "lbm"));
fprintf(1, "    Wbatt = %.6e lbm   \n",     UnitConversionPkg.ConvMass(Wbatt, "kg", "lbm"));
fprintf(1, "    Wfuel = %.6e lbm   \n",     UnitConversionPkg.ConvMass(Wfuel, "kg", "lbm"));
fprintf(1, "    S     = %.6e ft^2\n\n", S * UnitConversionPkg.ConvLength(1, "m", "ft") ^ 2);

% iterate until convergence
while (iter < MaxIter)
           
    % clear mission history and/or size the aircraft after first iteration
    if (iter > 0)
        
        % iterate on OEW for on-design only
        if (Type > 0)
            Aircraft = OEWPkg.OEWIteration(Aircraft);
        end
        
        % clear arrays from the mission analysis
        Aircraft = DataStructPkg.ClearMission(Aircraft);

        if (Aircraft.Settings.VisualizeAircraft == 1)

            % calculate scale factor for the geometry
            SF = Aircraft.Specs.Aero.S / Snominal;
            
            % visualize geometry for updated aircraft size
            Aircraft = VisualizationPkg.GeometryDriver(Aircraft, 0, SF, LengthNominal);

        end
        
    else

        % Size installed propulsion hardware only for an on-design analysis.
        % Off-design analysis must retain the original sized engines, motors,
        % fans, and their weights while iterating mission fuel and MTOW.
        if (Type > 0)
            Aircraft = PropulsionPkg.PropulsionSizing(Aircraft);
        end
        
    end
    
    % get the updated MTOW
    MTOW = Aircraft.Specs.Weight.MTOW;

    % ClearMission zeros LamUps/LamDwn between sizing iterations; refill the
    % PowerOpt schedule before flying so battery sizing sees the requested splits.
    Aircraft = PropulsionPkg.LamFill(Aircraft);

    % Regular off-design operation uses the battery only on the main
    % mission. Reserve and diversion missions must remain turbine-only;
    % otherwise the generic segment-level Clb schedule applies the 30%
    % motor availability cap to reserve climbs as well. Besides understating
    % reserve fuel, that previously left nonzero battery Pout after the pack
    % had reached its minimum SOC. Apply this before FlyMission so the -1
    % split recomputation sees zero motor availability on every reserve row.
    if Type == -1
        ReserveSegs = find(Aircraft.Mission.Profile.ID ~= 1);
        if ~isempty(ReserveSegs)
            ReservePts = [];
            for iReserveSeg = ReserveSegs(:).'
                ReservePts = [ReservePts, ...
                    Aircraft.Mission.Profile.SegBeg(iReserveSeg): ...
                    Aircraft.Mission.Profile.SegEnd(iReserveSeg)]; %#ok<AGROW>
            end
            ReservePts = unique(ReservePts);
            TrnType = Aircraft.Specs.Propulsion.PropArch.TrnType;
            iEM = find(TrnType == 0);
            iGT = find(TrnType == 1);
            iFan = find(TrnType == 2);
            Aircraft.Specs.Power.LamUps.Miss(ReservePts, iEM) = 0;
            Aircraft.Specs.Power.LamDwn.Miss(ReservePts, iEM) = 0;
            Aircraft.Specs.Power.LamDwn.Miss(ReservePts, iGT) = 1;
            Aircraft.Specs.Power.LamDwn.Miss(ReservePts, iFan) = 0.5;
            Aircraft.Mission.History.SI.Power.LamUps = ...
                Aircraft.Specs.Power.LamUps.Miss;
            Aircraft.Mission.History.SI.Power.LamDwn = ...
                Aircraft.Specs.Power.LamDwn.Miss;
        end
    end

    % In optimization mode (-2), LamDwn.Miss is the commanded output share
    % and must not be recomputed. LamUps is installed availability, so keep
    % every transmitter at its full rating even when LamDwn is zero. Regular
    % off-design mode (-1) retains its prescribed LamUps schedule and
    % recomputes feasible operational splits.
    PreserveOptimizationLamUps = isfield(Aircraft.Settings, ...
        "PreserveOptimizationLamUps") && ...
        logical(Aircraft.Settings.PreserveOptimizationLamUps);
    if Type == -2 && ~PreserveOptimizationLamUps
        Aircraft.Specs.Power.LamUps.Miss(:) = 1;
        Aircraft.Mission.History.SI.Power.LamUps = ...
            Aircraft.Specs.Power.LamUps.Miss;
    end

    % fly the mission
    Aircraft = MissionSegsPkg.FlyMission(Aircraft);
            
    % get fuel burn
    Fburn = Aircraft.Mission.History.SI.Weight.Fburn(end);
    
    % Compute the fuel-burn weight change. Power-optimization evaluations
    % may cross the battery-depletion boundary and create a fuel fixed-point
    % cycle, so allow an explicitly requested under-relaxed update. The fixed
    % point is unchanged; only the path used to reach it is damped.
    FuelRelaxation = 1;
    if isfield(Aircraft.Settings.Analysis, "FuelRelaxation") && ...
            ~isnan(Aircraft.Settings.Analysis.FuelRelaxation)
        FuelRelaxation = Aircraft.Settings.Analysis.FuelRelaxation;
    end
    dWfuel = FuelRelaxation .* (Fburn - Wfuel);
        
    % Off-design analysis flies the already-sized aircraft. Iterate the
    % carried fuel and takeoff weight, but keep the installed battery fixed.
    % Battery resizing is an on-design operation only.
    if ((Type < 0) || BattSizeFixed)
        
        % fixed battery weight
        dWbatt = 0;
        
    else
        
        % resize the battery for power and energy
        Aircraft = BatteryPkg.ResizeBattery(Aircraft);

        % Detect repeated cycles in the detailed battery's integer parallel-
        % cell configuration. Once detected, select and lock the smallest
        % battery state in the repeated cycle so the rest of the aircraft can
        % continue sizing around a fixed battery.
        if (DetectBattCycle)

            if (BattHistoryCount < BattCycleHistoryLength)
                BattHistoryCount = BattHistoryCount + 1;
            else
                BattSizeHistory(1:(end - 1), :) = BattSizeHistory(2:end, :);
                BattCellHistory(1:(end - 1), :) = BattCellHistory(2:end, :);
            end

            BattSizeHistory(BattHistoryCount, :) = Aircraft.Specs.Weight.Batt(:).';
            BattCellHistory(BattHistoryCount, :) = Aircraft.Specs.Power.Battery.ParCells(:).';

            ActiveBattSizeHistory = BattSizeHistory(1:BattHistoryCount, :);
            ActiveBattCellHistory = BattCellHistory(1:BattHistoryCount, :);
            CyclePeriod = FindRepeatedCycle(ActiveBattCellHistory);

            if (CyclePeriod > 0)
                CycleRows = (BattHistoryCount - CyclePeriod + 1):BattHistoryCount;
                [~, SmallestCycleRow] = min(sum(ActiveBattSizeHistory(CycleRows, :), 2));
                FixedRow = CycleRows(SmallestCycleRow);

                Aircraft.Specs.Weight.Batt = ActiveBattSizeHistory(FixedRow, :);
                Aircraft.Specs.Power.Battery.ParCells = ActiveBattCellHistory(FixedRow, :);
                BattSizeFixed = true;

                Aircraft.Settings.BattCycleDetected = 1;
                Aircraft.Settings.BattCyclePeriod   = CyclePeriod;
                Aircraft.Settings.BattSizeFixed     = 1;

                fprintf(1, "Battery sizing limit cycle detected (period %d). " + ...
                           "Fixing the smallest cycle battery at %.6e lbm.\n\n", ...
                        CyclePeriod, ...
                        UnitConversionPkg.ConvMass(sum(Aircraft.Specs.Weight.Batt), "kg", "lbm"));
            end
        end
        
        % find the difference between the new and old battery weight
        dWbatt = Aircraft.Specs.Weight.Batt - Wbatt;
            
    end
    
    % update mtow
    mtow_new = MTOW + dWfuel + sum(dWbatt);
    dmtow = mtow_new - MTOW;
    
    % assess convergence (relative tolerance/error)
    fuel_conv = abs(dWfuel) ./ Wfuel;
    batt_conv = abs(dWbatt) ./ Wbatt;
    mtow_conv = abs(dmtow ) ./ MTOW ;
    
    % check for NaN (i.e. there's no component in the system
    if (any(isnan(fuel_conv)))
        fuel_conv(isnan(fuel_conv)) = 0;
    end
    
    if (any(isnan(batt_conv)))
        batt_conv(isnan(batt_conv)) = 0;
    end
    
    % update component weights
    Wfuel = Wfuel + dWfuel;
    Wbatt = Wbatt + dWbatt;
    Wpax  = Aircraft.Specs.Weight.Payload;
    Wcrew = Aircraft.Specs.Weight.Crew;
    
    % remember the new weights
    Aircraft.Specs.Weight.MTOW = mtow_new;
    Aircraft.Specs.Weight.Fuel = Wfuel;
    Aircraft.Specs.Weight.Batt = Wbatt;

    % compute the OEW when sizing
    if (Type > -2)
        Aircraft.Specs.Weight.OEW  = mtow_new - sum(Wfuel) - sum(Wbatt) - Wpax - Wcrew;
    end
    
    % remember the OEW and wing area
    OEW = Aircraft.Specs.Weight.OEW;
    S   = Aircraft.Specs.Aero.S;

    % get the electric components' weights
    Wem = Aircraft.Specs.Weight.EM;
    Weg = Aircraft.Specs.Weight.EG;
    
    % print iteration result (in english units)
    fprintf(1, "Iteration %2d:\n"         , iter                                                 );
    fprintf(1, "    MTOW  = %.6e lbm   \n", UnitConversionPkg.ConvMass(mtow_new, "kg", "lbm")    );
    fprintf(1, "    OEW   = %.6e lbm   \n", UnitConversionPkg.ConvMass(OEW     , "kg", "lbm")    );
    fprintf(1, "    Wbatt = %.6e lbm   \n", UnitConversionPkg.ConvMass(Wbatt   , "kg", "lbm")    );
    fprintf(1, "    Wfuel = %.6e lbm   \n", UnitConversionPkg.ConvMass(Wfuel   , "kg", "lbm")    );
    fprintf(1, "    Wem   = %.6e lbm   \n", UnitConversionPkg.ConvMass(Wem     , "kg", "lbm")    );
    fprintf(1, "    Weg   = %.6e lbm   \n", UnitConversionPkg.ConvMass(Weg     , "kg", "lbm")    );
    fprintf(1, "    S     = %.6e ft^2\n\n", S * UnitConversionPkg.ConvLength(1 , "m" , "ft" ) ^ 2);
    
    % iterate
    iter = iter + 1;
    
    % if first iteration and sizing, need to run OEW iteration
    if ((iter == 1) && (Type > 0))
        continue;
    end
    
    % check if energy source weights have converged
    if ((~any(fuel_conv > EPS)) && ...
        (~any(batt_conv > EPS)) && ...
        (~any(mtow_conv > EPS))  )
        break;
    end 
end

% Record the number of completed sizing/analysis iterations.
Aircraft.Settings.Analysis.Iterations = iter;

% print warning if maximum iterations reached
if (iter == MaxIter)
    
    % print a warning
    warning('WARNING - EAPAnalysis: maximum number of sizing/analysis iterations reached.');
    
    % show that it didn't converge
    Aircraft.Settings.Converged = 0;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                          %
% DELETE UNNECESSARY VARIABLES FROM THE STRUCTURE          %
%                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% length of the aircraft
if (isfield(Aircraft, "LengthSet"))
    Aircraft = rmfield(Aircraft, "LengthSet");
end

% geometry configuration
if (isfield(Aircraft, "Preset"))
    Aircraft = rmfield(Aircraft, "Preset");
end

% reference geometry
if (isfield(Aircraft, "RefParts"))
    Aircraft = rmfield(Aircraft, "RefParts");
end
   
% scaled geometry
if (isfield(Aircraft, "TempParts"))
    Aircraft = rmfield(Aircraft, "TempParts");
end

% ----------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
% Battery Degradation          %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% grounding time
GroundTime = Aircraft.Specs.Battery.GroundT;

% LIB chemistry material
BattChem = Aircraft.Specs.Battery.Chem;

% battery charging rate in [W]
Cpower = Aircraft.Specs.Battery.Cpower;

% FEC
FECs = Aircraft.Specs.Battery.FEC(end);

if Type ~= 1 % Battery degradation only makes sense in off-design 
    if Aircraft.Specs.Battery.Degradation == 1
        [SOH, FEC, Aircraft] = BatteryPkg.CyclAging(Aircraft, BattChem, FECs, GroundTime, Cpower);
        Aircraft.Specs.Battery.FEC(end+1,1) = FEC;
        Aircraft.Specs.Battery.SOH(end+1,1) = SOH;
    end
end

% ----------------------------------------------------------

end

% ----------------------------------------------------------

function [Period] = FindRepeatedCycle(History)
% Find a multi-state cycle repeated twice at the end of a history matrix.
% A period-one repetition is ordinary convergence and is intentionally
% excluded. Exact comparison is appropriate because detailed battery sizing
% produces integer parallel-cell counts.

Period = 0;
NumStates = size(History, 1);

for CandidatePeriod = 2:floor(NumStates / 2)
    PreviousCycle = History((end - 2 * CandidatePeriod + 1):(end - CandidatePeriod), :);
    CurrentCycle  = History((end -     CandidatePeriod + 1):end, :);

    HasMultipleStates = size(unique(CurrentCycle, "rows"), 1) > 1;

    if (HasMultipleStates && isequaln(PreviousCycle, CurrentCycle))
        Period = CandidatePeriod;
        return
    end
end

end
